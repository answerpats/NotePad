package com.mycompany.notepad;  

import java.awt.*;  
import java.awt.event.ActionListener;  
import java.io.*;  
import java.sql.*;  
import java.util.ArrayList;  
import java.util.List;  
import javax.swing.*;  
import javax.swing.filechooser.FileNameExtensionFilter;  
import org.apache.poi.xwpf.usermodel.XWPFDocument;  
import org.apache.poi.xwpf.usermodel.XWPFParagraph;  

public class Notepad {  

    private JFrame frame;  
    private JTextArea textArea;  
    private JFileChooser fileChooser;  
    private JComboBox<String> lineSpacingComboBox;  
    private String currentLineSpacing = "Single";  

    // Database connection details  
    private static final String DB_URL = "jdbc:mysql://localhost/noteq"; // Update with your DB URL  
    private static final String DB_USER = "root";                           // Update with your DB user  
    private static final String DB_PASSWORD = "";                           // Update with your DB password  

    public Notepad() {  
        initializeComponents();  
        setupMenuBar();  
        setupFrame();  
    }  

    private void initializeComponents() {  
        frame = new JFrame("Notepad");  
        textArea = new JTextArea();  
        textArea.setFont(new Font("Arial", Font.PLAIN, 16));  

        // Create a panel with margins  
        JPanel panel = new JPanel(new BorderLayout());  
        panel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20)); // Set margins  

        // Add JTextArea to a JScrollPane for scrolling capability  
        JScrollPane scrollPane = new JScrollPane(textArea);  
        panel.add(scrollPane, BorderLayout.CENTER); // Add the scroll pane to the panel  

        frame.add(panel, BorderLayout.CENTER);  
        fileChooser = new JFileChooser();  
    }  

    private void setupMenuBar() {  
        JMenuBar menuBar = new JMenuBar();  

        // File Menu  
        JMenu fileMenu = new JMenu("File");  
        fileMenu.add(createMenuItem("Open Text File", e -> openFile()));  
        fileMenu.add(createMenuItem("Open Word File", e -> openWordFile()));  
        fileMenu.add(createMenuItem("Save", e -> saveFileToDatabase()));  
        fileMenu.addSeparator();  
        fileMenu.add(createMenuItem("Exit", e -> System.exit(0)));  
        menuBar.add(fileMenu);  

        // Format Menu  
        JMenu formatMenu = new JMenu("Format");  
        formatMenu.add(createMenuItem("Set Font Size", e -> setFontSize()));  
        formatMenu.add(createMenuItem("Set Font Color", e -> setFontColor()));  
        formatMenu.add(createMenuItem("Set Background Color", e -> setBackgroundColor()));  
        formatMenu.addSeparator();  

        // Text Alignment submenu  
        JMenu alignmentMenu = new JMenu("Text Alignment");  
        alignmentMenu.add(createMenuItemWithIcon("Left Align", null, e -> setAlignment(SwingConstants.LEFT)));  
        alignmentMenu.add(createMenuItemWithIcon("Center Align", null, e -> setAlignment(SwingConstants.CENTER)));  
        alignmentMenu.add(createMenuItemWithIcon("Right Align", null, e -> setAlignment(SwingConstants.RIGHT)));  
        formatMenu.add(alignmentMenu);  

        // Line Spacing options  
        formatMenu.add(createLineSpacingMenu());  

        menuBar.add(formatMenu);  

        // Recent Documents  
        JMenu recentMenu = new JMenu("Recent");  
        recentMenu.add(createMenuItem("Show Recent Documents", e -> showRecentDocuments()));  
        menuBar.add(recentMenu);  

        frame.setJMenuBar(menuBar);  
    }  

    private JMenuItem createMenuItem(String title, ActionListener actionListener) {  
        JMenuItem menuItem = new JMenuItem(title);  
        menuItem.addActionListener(actionListener);  
        return menuItem;  
    }  

    private JMenuItem createMenuItemWithIcon(String title, String iconPath, ActionListener actionListener) {  
        JMenuItem menuItem = new JMenuItem(title);  
        menuItem.addActionListener(actionListener);  
        if (iconPath != null) {  
            menuItem.setIcon(new ImageIcon(iconPath)); // Load your icons here if available  
        }  
        return menuItem;  
    }  

    private JPanel createLineSpacingMenu() {  
        JPanel panel = new JPanel();  
        panel.setLayout(new FlowLayout(FlowLayout.LEFT));  
        String[] lineSpacingOptions = {"Single", "1.5", "Double"};  
        lineSpacingComboBox = new JComboBox<>(lineSpacingOptions);  
        lineSpacingComboBox.setSelectedItem("Single");  
        lineSpacingComboBox.addActionListener(e -> setLineSpacing((String) lineSpacingComboBox.getSelectedItem()));  

        panel.add(new JLabel("Line Spacing:"));  
        panel.add(lineSpacingComboBox);  
        return panel;  
    }  

    private void setAlignment(int alignment) {  
        // Alignment may not work exactly as intended in JTextArea  
        StringBuilder paddedText = new StringBuilder(textArea.getText().trim());  
        String[] lines = paddedText.toString().split("\n");  
        paddedText.setLength(0); // Clear it for new formatting  

        for (String line : lines) {  
            switch (alignment) {  
                case SwingConstants.LEFT:  
                    paddedText.append(line).append("\n");  
                    break;  
                case SwingConstants.CENTER:  
                    paddedText.append(String.format("%" + ((textArea.getWidth() / 15) / 2 + line.length() / 2) + "s", line)).append("\n");  
                    break;  
                case SwingConstants.RIGHT:  
                    paddedText.append(String.format("%" + (textArea.getWidth() / 15) + "s", line)).append("\n");  
                    break;  
            }  
        }  
        textArea.setText(paddedText.toString());  
    }  

    private void setLineSpacing(String spacing) {  
        switch (spacing) {  
            case "Single":  
                currentLineSpacing = "Single";  
                break;  
            case "1.5":  
                currentLineSpacing = "1.5";  
                break;  
            case "Double":  
                currentLineSpacing = "Double";  
                break;  
        }  
        adjustLineSpacing();  
    }  

    private void adjustLineSpacing() {  
        // A simple simulation of line spacing  
        String[] lines = textArea.getText().split("\n");  
        StringBuilder spacedText = new StringBuilder();  
        for (String line : lines) {  
            spacedText.append(line).append("\n");  
            if ("1.5".equals(currentLineSpacing)) {  
                spacedText.append("\n");  
            } else if ("Double".equals(currentLineSpacing)) {  
                spacedText.append("\n");  
            }  
        }  
        textArea.setText(spacedText.toString().trim());  
    }  

    private void setupFrame() {  
        // Set the size of the JFrame window to match A4 dimensions (794 pixels width x 1100 pixels height)  
        frame.setSize(794, 1100); // Set width to A4 width (794 pixels) and height to 1100 pixels  
        frame.setResizable(true); // Allow the frame to be resizable  
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        frame.setLocationRelativeTo(null); // Center the JFrame on the screen  
        frame.setVisible(true);  
    }  

    private void openFile() {  
        fileChooser.setFileFilter(new FileNameExtensionFilter("Text Files", "txt"));  
        int returnValue = fileChooser.showOpenDialog(frame);  
        if (returnValue == JFileChooser.APPROVE_OPTION) {  
            File selectedFile = fileChooser.getSelectedFile();  
            try (BufferedReader reader = new BufferedReader(new FileReader(selectedFile))) {  
                textArea.setText("");  
                String line;  
                while ((line = reader.readLine()) != null) {  
                    textArea.append(line + "\n");  
                }  
            } catch (IOException ex) {  
                showErrorDialog("Error opening file: " + ex.getMessage());  
            }  
        }  
    }  

    private void openWordFile() {  
        fileChooser.setFileFilter(new FileNameExtensionFilter("Word Documents", "docx"));  
        int returnValue = fileChooser.showOpenDialog(frame);  
        if (returnValue == JFileChooser.APPROVE_OPTION) {  
            File selectedFile = fileChooser.getSelectedFile();  
            try (FileInputStream fis = new FileInputStream(selectedFile);  
                 XWPFDocument document = new XWPFDocument(fis)) {  

                textArea.setText("");  
                for (XWPFParagraph paragraph : document.getParagraphs()) {  
                    textArea.append(paragraph.getText() + "\n");  
                }  
            } catch (IOException ex) {  
                showErrorDialog("Error opening Word file: " + ex.getMessage());  
            }  
        }  
    }  

    private void saveFileToDatabase() {  
        String filename = JOptionPane.showInputDialog(frame, "Enter file name:");  
        if (filename != null && !filename.trim().isEmpty()) {  
            String content = textArea.getText();  
            saveToDatabase(filename, content);  
        }  
    }  

    private void saveToDatabase(String filename, String content) {  
        String sql = "INSERT INTO note (filename, content, created_at, updated_at) VALUES (?, ?, NOW(), NOW())";  

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);  
             PreparedStatement pstmt = conn.prepareStatement(sql)) {  
            pstmt.setString(1, filename);  
            pstmt.setString(2, content);  
            pstmt.executeUpdate();  
            JOptionPane.showMessageDialog(frame, "File saved to database successfully!");  
        } catch (SQLException ex) {  
            showErrorDialog("Error saving to database: " + ex.getMessage());  
        }  
    }  

    private void setFontSize() {  
        String sizeStr = JOptionPane.showInputDialog(frame, "Enter font size:", "16");  
        if (sizeStr != null && !sizeStr.isEmpty()) {  
            try {  
                int fontSize = Integer.parseInt(sizeStr);  
                textArea.setFont(new Font(textArea.getFont().getFontName(), Font.PLAIN, fontSize));  
            } catch (NumberFormatException ex) {  
                showErrorDialog("Invalid font size. Please enter a number.");  
            }  
        }  
    }  

    private void setFontColor() {  
        Color color = JColorChooser.showDialog(frame, "Choose Font Color", textArea.getForeground());  
        if (color != null) {  
            textArea.setForeground(color);  
        }  
    }  

    private void setBackgroundColor() {  
        Color color = JColorChooser.showDialog(frame, "Choose Background Color", textArea.getBackground());  
        if (color != null) {  
            textArea.setBackground(color);  
        }  
    }  

    private void showErrorDialog(String message) {  
        JOptionPane.showMessageDialog(frame, message, "Error", JOptionPane.ERROR_MESSAGE);  
    }  

    private void showRecentDocuments() {  
        String sql = "SELECT filename FROM note ORDER BY created_at DESC LIMIT 10"; // Modify this based on your needs  

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);  
             PreparedStatement pstmt = conn.prepareStatement(sql);  
             ResultSet rs = pstmt.executeQuery()) {  

            List<String> filenames = new ArrayList<>();  
            while (rs.next()) {  
                filenames.add(rs.getString("filename"));  
            }  

            if (filenames.isEmpty()) {  
                JOptionPane.showMessageDialog(frame, "No recent documents found.", "Recent Documents", JOptionPane.INFORMATION_MESSAGE);  
                return;  
            }  

            // Create a JList to display filenames  
            JList<String> fileList = new JList<>(filenames.toArray(new String[0]));  
            fileList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);  
            JScrollPane scrollPane = new JScrollPane(fileList);  
            scrollPane.setPreferredSize(new Dimension(300, 150));  

            // Show the list in a dialog  
            int option = JOptionPane.showConfirmDialog(frame, scrollPane, "Recent Documents", JOptionPane.OK_CANCEL_OPTION);  
            if (option == JOptionPane.OK_OPTION) {  
                String selectedFile = fileList.getSelectedValue();  
                if (selectedFile != null) {  
                    openDocumentFromDatabase(selectedFile);  
                }  
            }  

        } catch (SQLException ex) {  
            showErrorDialog("Error retrieving recent documents: " + ex.getMessage());  
        }  
    }  

    private void openDocumentFromDatabase(String filename) {  
        String sql = "SELECT content FROM note WHERE filename = ?";  

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);  
             PreparedStatement pstmt = conn.prepareStatement(sql)) {  
            pstmt.setString(1, filename);  
            try (ResultSet rs = pstmt.executeQuery()) {  
                if (rs.next()) {  
                    String content = rs.getString("content");  
                    textArea.setText(content);  
                } else {  
                    showErrorDialog("No content found for the selected document.");  
                }  
            }  
        } catch (SQLException ex) {  
            showErrorDialog("Error opening document: " + ex.getMessage());  
        }  
    }  

    public static void main(String[] args) {  
        SwingUtilities.invokeLater(Notepad::new);  
    }  

    private enum Alignment {  
        LEFT, CENTER, RIGHT  
    }  
}